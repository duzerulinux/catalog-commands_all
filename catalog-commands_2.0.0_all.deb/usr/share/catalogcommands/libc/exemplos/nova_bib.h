#ifndef _NOVA_BIBLIOTECA
#define _NOVA_BIBLIOTECA 
#include <stdio.h> 
int fatorial(int);
int fibonacci(int);
#endif 
